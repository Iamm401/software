//app.js
import {
  request,
  requestNoBaseUrl
} from "/request/index";
import {
  login,
  showToast
} from "/utils/asyncWx.js";
import regeneratorRuntime from "/lib/runtime/runtime.js";
App({
  onLaunch: function () {
  },
  globalData: {
    // POST,DELETE,PUT请求的header
    requestPostHeader: {
      "Content-Type": "application/x-www-form-urlencoded"
    },

  },
  //预览图片
  previewImages(allImgerc, nowImgSrc) {
    if (!nowImgSrc) nowImgSrc = allImgerc[0];
    wx.previewImage({
      current: nowImgSrc,
      urls: allImgerc,
      success: (result) => {},
      fail: (err) => {
        console.log(err);
      },
      complete: () => {},
    });
  },
});