var app = getApp();
import regeneratorRuntime from "../../lib/runtime/runtime.js";
import {
  showToast,
  showModal,
  showModalPlus,
  showLoading,
  showWarnToast
} from "../../utils/asyncWx.js";
import { request, requestNoBaseUrl } from "../../request/index";
// pages/movie_detail/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isLoading:true,
    movieDetail:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const {id} = options;
    Promise.all([this.getMovieDetail(id)]).then(res=>{
      this.setData({
        isLoading:false
      })
    }).catch(err=>{
      this.setData({
        isLoading:false
      })
      showWarnToast({ title: "加载失败!", duration: 1111 });
    })
  },

  async getMovieDetail(id){
    try {
      const res = await request({url:'/movie/movieDetail',data:{id}})
      if(res.code && res.code !== 200) throw new Error(res.message)
      res.rate = res.rate.toFixed(1)
      this.setData({
        movieDetail:res
      })
    } catch (error) {
      throw new Error(error)
    }
  },

  handleCopyText(e){
    wx.setClipboardData({
      data: e.currentTarget.dataset.value,
    });
  },

  handleTouchStart(e){
    this.touchStart = e.timeStamp;
  },

  handleTouchEnd(e){
    this.touchEnd = e.timeStamp;
  },

  handlePreViewImg(e){
    const {url} = e.currentTarget.dataset;
    app.previewImages([url],url);
  }
 
})