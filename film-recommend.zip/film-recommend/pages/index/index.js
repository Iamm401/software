var app = getApp();
import regeneratorRuntime from "../../lib/runtime/runtime.js";
import {
  showLoading,
  showWarnToast,
} from "../../utils/asyncWx.js";
import { request, requestNoBaseUrl } from "../../request/index";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    tabIndex: 0,
    isLoading: true,
    recommendMovieList: [],
    rateMovieList: [],
    isShowEnd_1: false,
    isShowEnd_2: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    Promise.all([this.getRecommendMovieList()])
      .then((res) => {
        this.setData({
          isLoading: false,
        });
      })
      .catch((err) => {
        this.setData({
          isLoading: false,
        });
        showWarnToast({ title: "加载失败!", duration: 1111 });
      });
  },

  pageParams: {
    refreshTime: 0,
    pageNum: 0,
    pageSize: 18,
  },

  totalNum: 0,
  totalPages: 0,

  ratePageParams: {
    refreshTime: 0,
    pageNum: 0,
    pageSize: 18,
  },

  rateTotalNum: 0,
  rateTotalPages: 0,

  async getRecommendMovieList() {
    try {
      const pageParams = { ...this.pageParams };
      ++pageParams.pageNum;
      if (pageParams.pageNum === 1)
        pageParams.refreshTime = new Date().getTime();
      const res = await request({
        url: "/movie/movieList",
        data: { ...pageParams },
      });
      if (res.code && res.code !== 200) throw new Errror(res.message);
      const { total, pages, pageNum, data } = res;
      this.pageParams.pageNum = pageNum;
      this.totalNum = total;
      this.totalPages = pages;
      data.forEach((res) => {
        res.rate = res.rate.toFixed(1);
      });
      this.setData({
        ["recommendMovieList[" + (pageNum - 1) + "]"]: data,
      });
    } catch (error) {
      throw new Errror(error);
    }
  },

  async getRateMovieList() {
    try {
      const pageParams = { ...this.ratePageParams };
      ++pageParams.pageNum;
      if (pageParams.pageNum === 1)
        pageParams.refreshTime = new Date().getTime();
      const res = await request({
        url: "/movie/rate/movieList",
        data: { ...pageParams },
      });
      if (res.code && res.code !== 200) throw new Errror(res.message);
      const { total, pages, pageNum, data } = res;
      this.ratePageParams.pageNum = pageNum;
      this.rateTotalNum = total;
      this.rateTotalPages = pages;
      data.forEach((res) => {
        res.rate = res.rate.toFixed(1);
      });
      this.setData({
        ["rateMovieList[" + (pageNum - 1) + "]"]: data,
      });
    } catch (error) {
      throw new Errror(error);
    }
  },

  handleToAimPage(e) {
    const { url } = e.currentTarget.dataset;
    showLoading({ title: "页面跳转中..." });
    wx.navigateTo({
      url,
      success: (result) => {},
      fail: () => {},
      complete: () => {
        wx.hideLoading();
      },
    });
  },

  handleTabChange(e) {
    this.setData({
      tabIndex: e.detail.index,
    });
    switch (e.detail.index) {
      case 0:
        // if (this.totalNum === 0) {
        this.totalNum = 0;
        this.totalPages = 0;
        this.pageParams = {
          refreshTime: 0,
          pageNum: 0,
          pageSize: 18,
        };
        this.setData({
          recommendMovieList:[]
        })
        showLoading({
          title: "加载中",
        });
        Promise.all([this.getRecommendMovieList()])
          .then((res) => {
            wx.hideLoading();
          })
          .catch((err) => {
            wx.hideLoading();
          });
        // }
        break;
      case 1:
        // if(this.rateTotalNum === 0){
        this.ratePageParams = {
          refreshTime: 0,
          pageNum: 0,
          pageSize: 18,
        };
        this.rateTotalNum = 0;
        this.rateTotalPages = 0;
        this.setData({
          rateMovieList:[]
        })
        showLoading({
          title: "加载中",
        });
        Promise.all([this.getRateMovieList()])
          .then((res) => {
            wx.hideLoading();
          })
          .catch((err) => {
            wx.hideLoading();
          });
        // }
        break;
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    switch (this.data.tabIndex) {
      case 0:
        // 1 判断还有没有下一页数据
        if (this.pageParams.pageNum >= this.totalPages) {
          // 没有下一页数据
          this.setData({
            isShowEnd_1: true,
          });
        } else {
          // 没有下一页数据
          this.setData({
            isShowEnd_1: false,
          });
          showLoading({
            title: "加载中",
          });
          Promise.all([this.getRecommendMovieList()])
            .then((res) => {
              wx.hideLoading();
            })
            .catch((err) => {
              wx.hideLoading();
            });
        }
        break;
      case 1:
        // 1 判断还有没有下一页数据
        if (this.ratePageParams.pageNum >= this.rateTotalPages) {
          // 没有下一页数据
          this.setData({
            isShowEnd_2: true,
          });
        } else {
          // 没有下一页数据
          this.setData({
            isShowEnd_2: false,
          });
          showLoading({
            title: "加载中",
          });
          Promise.all([this.getRateMovieList()])
            .then((res) => {
              wx.hideLoading();
            })
            .catch((err) => {
              wx.hideLoading();
            });
        }
        break;
    }
  },
});
