//定义公共的url
// const baseUrl = `http://localhost:8080/wx_dream_land`;
const baseUrl = `https://www.yuzhangbaize.cn/wx_dream_land`;
var app = getApp();
import { showToast } from "../utils/asyncWx.js";
export const request = (params) => {
  // 判断 url中是否带有 /my/ 请求的私有的路径 带上 header userId
  let header = { ...params.header };
  if (params.url.includes("/my/")) {
    // 拼接header 带上token
    const myInfo = wx.getStorageSync("myInfo");
    header["Authorization"] = myInfo.uid || null;
  }

  return new Promise((resolve, reject) => {
    wx.request({
      ...params,
      header: header,
      url: baseUrl + params.url,
      success: (result) => {
        if (result.data.code != 200) {
          reject(result.data);
        }
        resolve(result.data.data ? result.data.data : result.data);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};
export const requestNoBaseUrl = (params) => {
  // 判断 url中是否带有 /my/ 请求的私有的路径 带上 header userId
  let header = { ...params.header };
  if (params.url.includes("/my/")) {
    // 拼接header 带上token
    const myInfo = app.getMyInfoFromStorage();
    if (myInfo && myInfo.uid) {
      header["Authorization"] = myInfo.uid;
    } else {
      showToast({ title: "抱歉!请先登录!", icon: "none", duration: 1000 });
      return;
    }
  }

  return new Promise((resolve, reject) => {
    wx.request({
      ...params,
      header: header,
      url: params.url,
      success: (result) => {
        if (result.data.code != 200) {
          reject(result.data);
        }
        resolve(result.data.data ? result.data.data : result.data);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};
