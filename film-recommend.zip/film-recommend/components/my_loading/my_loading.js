// components/my_loading/my_loading.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    'custom-class':{
      type:String,
      value:''
    },
    'color':{
      type:String,
      value:'#00AEFF'
    },
    fcolor:{
      type:String,
      value:'#333'
    },
    'type':{
      type:String,
      value:'circular'
    },
    'size':{
      type:String,
      value:'99rpx'
    },
    'text-size':{
      type:String,
      value:'36.66rpx'
    },
    vertical:{
      type:Boolean,
      value:true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
