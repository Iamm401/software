// components/SwipeGestures/SwipeGestures.js
var minOffset = 99; //最小偏移量，低于这个值不响应滑动处理
var minTime = 60; // 最小时间，单位：毫秒，低于这个值不响应滑动处理
var startX = 0; //开始时的X坐标
var startY = 0; //开始时的Y坐标
var startTime = 0; //开始时的毫秒数
var app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    extClass: {
      type: String,
      value: "",
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    height: 99,
  },

  ready() {
    this.setData({
      height:
        app.globalSystemInfo.screenHeight -
        app.globalSystemInfo.navBarHeight +
        app.globalSystemInfo.navBarExtendHeight -
        9.99,
    });
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /**
     * 触摸开始事件，初始化startX、startY和startTime
     */
    touchStart: function (e) {
      startX = e.touches[0].pageX; // 获取触摸时的x坐标
      startY = e.touches[0].pageY; // 获取触摸时的x坐标
      startTime = new Date().getTime(); //获取毫秒数
    },
    /**
     * 触摸取消事件 （手指触摸动作被打断，如来电提醒，弹窗），要将startX、startY和startTime重置
     */
    touchCancel: function (e) {
      startX = 0; //开始时的X坐标
      startY = 0; //开始时的Y坐标
      startTime = 0; //开始时的毫秒数
    },
    /**
     * 触摸结束事件，主要的判断在这里
     */
    touchEnd: function (e) {
      var endX = e.changedTouches[0].pageX;
      var endY = e.changedTouches[0].pageY;
      var touchTime = new Date().getTime() - startTime; //计算滑动时间
      //开始判断
      //1.判断时间是否符合
      if (touchTime >= minTime) {
        //2.判断偏移量：分X、Y
        var xOffset = endX - startX;
        var yOffset = endY - startY;
        //①条件1（偏移量x或者y要大于最小偏移量）
        //②条件2（可以判断出是左右滑动还是上下滑动）
        if (
          Math.abs(xOffset) >= Math.abs(yOffset) &&
          Math.abs(xOffset) >= minOffset
        ) {
          //左右滑动
          //③条件3（判断偏移量的正负）
          if (xOffset < 0) {
            console.log("向左滑动");
            this.triggerEvent('swipeleft', { delta: this.data.delta });
          } else {
            console.log("向右滑动");
            this.triggerEvent('swiperight', { delta: this.data.delta });
          }
        } else if (
          Math.abs(xOffset) < Math.abs(yOffset) &&
          Math.abs(yOffset) >= minOffset
        ) {
          //上下滑动
          //③条件3（判断偏移量的正负）
          if (yOffset < 0) {
            console.log("向上滑动");
            this.triggerEvent('swipeup', { delta: this.data.delta });
          } else {
            console.log("向下滑动");
            this.triggerEvent('swipedown', { delta: this.data.delta });
          }
        }
      } else {
        console.log("滑动时间过短", touchTime);
      }
    },
  },
});
