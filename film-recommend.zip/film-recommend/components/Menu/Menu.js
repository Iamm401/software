//Component Object
Component({
  properties: {
  },
  data: {
    showDialog: false
  },
  methods: {
    toggleDialog() {
      this.setData({
        showDialog: !this.data.showDialog
      });
    },
  },
  created: function(){
    
  }
  
});