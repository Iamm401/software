// components/topSearch/topSearch.js
const app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    background: {
      type: String,
      value: "#2cade4",
    },
    defaultSearchValue: {
      type: String,
      value: "",
    },
    isShowMask:{
      type:Boolean,
      value:false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    pageOptBtn: {
      back: true,
      home: false,
    },
    searchContent: "",
  },

  ready() {
    const pages = getCurrentPages();
    const length = pages.length;
    this.setData({
      pageOptBtn:{
        home:length == 1 && app.globalData.homePageRoute !== pages[length - 1].route,
        back: length !== 1,
      }
    });
  },
  /**
   * 组件的方法列表
   */
  methods: {


    // 返回事件
    back: function () {
      wx.navigateBack({
        delta: 1,
      });
      this.triggerEvent("back", { delta: this.data.delta });
    },
    home: function () {
      wx.redirectTo({
        url: `/${app.globalData.homePageRoute}`,
      });
      this.triggerEvent("home", {});
    },

    focus(e) {
      this.setData({
        isShowMask:true
      })
      this.triggerEvent("focus", e);
    },
    blur(e) {
      this.setData({
        isShowMask:false,
      })
      this.triggerEvent("blur", e);
    },
    searchInput(e) {
      this.setData({
        searchContent: e.detail.value,
      });
      this.triggerEvent("input", e);
    },
    searchConfirm() {
      this.triggerEvent("confirm", { value: this.data.searchContent });
    },
    clearContent(){
      this.contentClear();  
      this.triggerEvent("clear");
    },
    contentClear(){
      this.setData({
        defaultSearchValue:'',
        searchContent:''
      })
    },
    menuClick() {
      this.triggerEvent("menuClick");
    },
  },
});
