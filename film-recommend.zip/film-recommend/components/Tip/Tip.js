// components/Tip/Tip.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        tipIconSrc: {
            type: String,
            value: ''
        },
        contentText: {
            type: String,
            value: ''
        },
        imageStyle:{
            type:String,
            value:''
        },
        height: {
            type: String,
            value: '100%'
        },
        contentFontSize: {
            type: String,
            value: '28rpx'
        },
        contentBottom: {
            type: String,
            value: '36.66%'
        },
        type:{
            type:String,
            value:''
        }
    },

    

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {

    }
})