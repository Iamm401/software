'use strict';

Component({
  properties: {
    exClass:{
      type:String,
      value:''
    },
    type: {
      type: String,
      value: 'loading'
    },
    isShow:{
      type:Boolean,
      value:false
    },
    loading_tips:{
      type: String,
      value: '加载中...'
    },
    loadingTipsColor:{
      type: String,
      value: ''
    },
    text: {
      type: String,
      value: '没有更多了'
    },
    textColor:{
      type:String,
      value:''
    },
    isEnd:{
      type:Boolean,
      value:false
    },
    errMsg:{
      type:String,
      value:'没加载出来. 重新试试吧!'
    },
    errMsgColor:{
      type:String,
      value:'red'
    },
    isErr:{
      type:Boolean,
      value:false
    }
  },
  data: {

  },
  methods: {
    
  },
});