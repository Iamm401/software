/**
 * promise形式的 getSetting
 */
export const getSetting = () => {
  return new Promise((resolve, reject) => {
    wx.getSetting({
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
    });
  });
};

/**
 * promise形式的 chooseAddress
 */
export const chooseAddress = () => {
  return new Promise((resolve, reject) => {
    wx.chooseAddress({
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
    });
  });
};

/**
 * promise形式的 openSetting
 */
export const openSetting = () => {
  return new Promise((resolve, reject) => {
    wx.openSetting({
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
    });
  });
};

/**
 * promise形式的 showModal
 */
export const showModal = ({ content }) => {
  return new Promise((resolve, reject) => {
    wx.showModal({
      title: "提示",
      content: content,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
    });
  });
};

/**
 * promise形式的 showModal
 */
export const showModalPlus = ({
  title,
  content,
  cancelText,
  cancelColor,
  confirmText,
  confirmColor,
}) => {
  return new Promise((resolve, reject) => {
    wx.showModal({
      title: title,
      content: content,
      showCancel: true,
      cancelText: cancelText,
      cancelColor: cancelColor,
      confirmText: confirmText,
      confirmColor: confirmColor,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
    });
  }).catch((err) => {});
};

/**
 * promise形式的 showToast
 */
export const showWarnToast = ({ title, duration }) => {
  return new Promise((resolve, reject) => {
    wx.showToast({
      title: title,
      icon: "none",
      image: "/icon/toast/warn.png",
      duration: duration,
      mask: true,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  }).catch((err) => {});
};

export const showToast = ({ title, icon, duration }) => {
  return new Promise((resolve, reject) => {
    wx.showToast({
      title: title,
      icon: icon,
      image: "",
      duration: duration,
      mask: true,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  }).catch((err) => {});
};

/**
 * promise形式的 login
 */
export const login = () => {
  return new Promise((resolve, reject) => {
    wx.login({
      timeout: 10000,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
    });
  }).catch((err) => {});
};

/**
 * promise 形式的 小程序的微信支付
 * @param{object} 支付所必要的参数
 */
export const requestPayment = ({ pay }) => {
  return new Promise((resolve, reject) => {
    wx.requestPayment({
      // 解构
      ...pay,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};

/**
 * promise 形式的 获取用户信息
 * @param{object} 支付所必要的参数
 */
export const getUserInfo = () => {
  return new Promise((resolve, reject) => {
    wx.getUserInfo({
      withCredentials: "false",
      lang: "zh_CN",
      timeout: 10000,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};

/**
 * promise 形式的 获取用户信息
 * @param{object} 支付所必要的参数
 */
export const uploadFile = ({ url, filePath, name, formData }) => {
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: url,
      filePath: filePath,
      name: name,
      formData: formData,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};

/**
 * promise 形式的 session_key检查
 * @param{object} 支付所必要的参数
 */
export const checkSession = () => {
  return new Promise((resolve, reject) => {
    wx.checkSession({
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};

export const showLoading = ({ title }) => {
  return new Promise((resolve, reject) => {
    wx.showLoading({
      title,
      mask: true,
      success: (result) => {
        resolve(result);
      },
      fail: (err) => {
        reject(err);
      },
      complete: () => {},
    });
  });
};
